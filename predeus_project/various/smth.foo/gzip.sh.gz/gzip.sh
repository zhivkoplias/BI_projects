#!/bin/bash

# This downloads whole series using tab-delimited format file

for f in $(ls *.foo); do gzip $f; done;
